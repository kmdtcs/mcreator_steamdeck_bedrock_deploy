# Bedrock deployment for MCreator and mcpelauncher

A Java plugin for **MCreator 2026.3.44621 (EAP)**. It adds configurable behavior and resource pack destinations to Preferences and a **Bedrock** menu with:

- **Export and install add-on to Minecraft...** — regenerate the current Bedrock workspace's resources and base files, run MCreator's Gradle `build`, then install the packs from the resulting `.mcaddon` automatically.
- **Install an exported .mcaddon...** — install a previously exported add-on without rebuilding.

The plugin uses MCreator's standard export artifact; you do not need to manually save, unpack, or copy an archive. It does not start Minecraft. The original MCreator export action remains available.

## Install on Steam Deck

1. Download `bedrock-deploy-1.0.0.zip`. Keep it zipped.
2. In MCreator, open **File → Preferences → Manage plugins**, click **Load plugin**, and select the ZIP. The label may be translated in your interface.
3. Restart MCreator. If Java plugins are disabled, enable them in MCreator's plugin settings and restart again.
4. Open **Preferences → Bedrock deployment**. Use **Browse...** to select the existing `behavior_packs` and `resource_packs` folders used by your Minecraft installation. Save the preferences.
5. Open your Bedrock add-on workspace and use **Bedrock → Export and install add-on to Minecraft...**. Let the build finish. If folders with the same names already exist, review the replacement dialog and choose **Replace packs** or **Cancel**. Cancel is the default.
6. Open Minecraft through mcpelauncher, then enable the behavior/resource packs in your world's settings. Close and reopen Minecraft if it was running during installation.

You can also install manually by placing the ZIP in MCreator's user plugins folder (normally `~/.mcreator/plugins/`) and restarting MCreator. If you configured `MCREATOR_HOME`, use its `plugins/` subfolder instead.

### Finding the game folders

For a Flathub installation, a common location is:

```text
/home/deck/.var/app/io.mrarm.mcpelauncher/data/mcpelauncher/games/com.mojang/behavior_packs
/home/deck/.var/app/io.mrarm.mcpelauncher/data/mcpelauncher/games/com.mojang/resource_packs
```

A native launcher commonly uses `~/.local/share/mcpelauncher/games/com.mojang/`. Launcher profiles or custom game data settings can change these paths. Confirm the active game data location in your launcher; the examples are not automatic detection. In Dolphin, enable **Show Hidden Files** to browse `.var` or `.local`.

Choose the pack container folders themselves, not a specific pack, the `com.mojang` parent, or a world's pack folder. Both folders must already exist, be writable, and be separate from one another. Create them in the correct game data location if Minecraft has not created them yet. Type absolute paths rather than `~` or environment variables.

If MCreator itself is sandboxed, grant that application access to the two selected game folders using its sandbox settings (for example, Flatseal for Flatpak). The plugin inherits MCreator's filesystem permissions.

## Replacement and recovery

- Packs retain their exported folder names and manifest UUIDs. Behavior and script packs go to the behavior destination; resource packs go to the resource destination.
- When a same-name folder exists, one dialog lists all folders that will be replaced. Replacement removes obsolete files too; it is not a merge. A pack with the same UUID in a *different* folder is not automatically removed.
- The complete archive is extracted and validated before any installed pack changes. Incoming files are staged in the destination filesystems. Existing folders are moved to temporary backups before the new folders are moved into place.
- If an installation operation fails, the plugin attempts to restore all previous folders. If recovery also fails, it retains `.mcreator-backup-*` folders beside the packs and reports that recovery is required. Preserve those folders and restore their contents manually after resolving the disk/permission problem.
- Successful installations remove temporary backups. This is rollback for ordinary I/O failures, not a durable transaction across power loss or forced process termination. Close Minecraft while deploying to avoid it reading a partly updated pair of packs.
- Existing symlink pack folders and non-directory collisions are refused. Newly appearing collisions are refused instead of being silently overwritten. Archives cannot extract outside the staging directory; limits are 50,000 entries and 1 GiB unpacked.

## Compatibility and scope

The manifest explicitly allows **2026.3.44621**, including the EAP version check. Other releases require reviewing the APIs, rebuilding, and changing `supportedversions`; they are not claimed as compatible.

The importer supports MCreator's standard `.mcaddon` layout: pack directories at the archive root, each containing `manifest.json`. It classifies packs from manifest module types (`data`/`script` or `resources`), rather than guessing from names. Nested `.mcpack` archives and other generators' custom layouts are outside this version's scope. A bad manifest aborts the import before installed packs change.

The workspace should be saved before export, just as with MCreator's standard export. The plugin follows `ExportWorkspaceForDistAction`'s resource/base generation and `build` sequence. It never edits world settings or enables experiments; Minecraft compatibility and experiment requirements still depend on your generator and game versions.

## Build from source

Unpack the matching official Linux MCreator build, which includes its JDK and libraries. From this source directory:

```bash
MCREATOR_HOME=/absolute/path/to/MCreatorEAP2026344621 ./build.sh
```

The ZIP is written to `dist/bedrock-deploy-1.0.0.zip`. No Gradle installation or dependency downloads are required; compilation uses MCreator's bundled libraries and JDK. Java sources target Java 21 bytecode, running in MCreator's bundled Java 25 runtime.

To exercise the real MCreator plugin loader, preferences, and localization using an isolated test user directory:

```bash
MCREATOR_HOME=/absolute/path/to/MCreatorEAP2026344621 ./smoke-test.sh
```

Tests do not touch your Minecraft folders. See `VALIDATION.md` for what was checked and the remaining manual verification.

## References and license

- [MCreator source](https://github.com/MCreator/MCreator), particularly `JavaPlugin`, `PreferencesSection`, `MCreatorLoadedEvent`, and `ExportWorkspaceForDistAction`.
- [MCreator 2026.3.44621 official EAP release](https://github.com/MCreator/MCreator/releases/tag/2026.3.44621).
- [MCreator Bedrock installation workflow](https://mcreator.net/wiki/how-install-minecraft-pe-bedrock-edition-add-ons-android-and-iphone).
- [mcpelauncher on Flathub](https://flathub.org/en/apps/io.mrarm.mcpelauncher).

Licensed under GPL-3.0-or-later; see `LICENSE.txt`. This is an independent plugin, not an official MCreator or mcpelauncher release.
